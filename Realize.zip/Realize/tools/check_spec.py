"""Validate specification artifacts; this does not execute an ORCHESTRA runtime."""

import ast
import copy
import csv
from html.parser import HTMLParser
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import sys
from uuid import UUID

from jsonschema import Draft202012Validator, FormatChecker
import yaml


ROOT = Path(__file__).resolve().parents[1]
CHECKS = []
FORMATS = FormatChecker()


@FORMATS.checks("date-time", raises=(ValueError, TypeError))
def utc_datetime(value):
    if not isinstance(value, str) or not value.endswith("Z"):
        return False
    parsed = datetime.fromisoformat(value[:-1] + "+00:00")
    return parsed.utcoffset() == timezone.utc.utcoffset(parsed)


@FORMATS.checks("uuid", raises=(ValueError, TypeError, AttributeError))
def uuid4(value):
    return isinstance(value, str) and str(UUID(value)) == value and UUID(value).version == 4


def check(name, condition, details=None):
    CHECKS.append({"check": name, "passed": bool(condition), "details": details})


def load(path):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def validator(name):
    return Draft202012Validator(load("contracts/" + name + ".schema.json"), format_checker=FORMATS)


def rejects(name, value):
    return not validator(name).is_valid(value)


def negative(name, original, change, title):
    value = copy.deepcopy(original)
    change(value)
    check(title, rejects(name, value))


def definitions(text):
    pattern = r"^\s*(?:- \*\*|\| \*\*|- \[ \] )((?:[A-Z]+|DoD)-\d{2})\b"
    return [{"id": m.group(1), "line": text[:m.start()].count("\n") + 1}
            for m in re.finditer(pattern, text, re.M)]


def main():
    master = (ROOT / "prompts/MASTER_PROMPT.md").read_text(encoding="utf-8")
    for path in sorted((ROOT / "contracts").glob("*.schema.json")):
        try:
            Draft202012Validator.check_schema(json.loads(path.read_text()))
            check("schema metaschema: " + path.name, True)
        except Exception as error:
            check("schema metaschema: " + path.name, False, type(error).__name__)

    examples = [("rpc", "rpc-query.json"), ("rpc", "rpc-response.json"),
                ("rpc", "rpc-human-answer.json"), ("charter", "charter.json"),
                ("map-node", "map-node.json"), ("verdict", "verdict.json")]
    for name, path in examples:
        errors = sorted(validator(name).iter_errors(load("examples/" + path)), key=lambda e: str(e.path))
        check("positive fixture: " + path, not errors,
              [str(list(e.path)) + ": " + e.message for e in errors])
    skill = yaml.safe_load((ROOT / "examples/skill.yaml").read_text())
    check("skill YAML parses and validates", validator("skill").is_valid(skill))
    for side in ("input", "output"):
        try:
            Draft202012Validator.check_schema(skill["signature"][side])
            check("skill real JSON Schema: " + side, True)
        except Exception:
            check("skill real JSON Schema: " + side, False)
    skill_input = Draft202012Validator(skill["signature"]["input"])
    check("skill schema accepts typed input", skill_input.is_valid({"value": "hello"}))
    check("skill schema rejects wrong type", not skill_input.is_valid({"value": 42}))
    check("skill schema rejects extra field", not skill_input.is_valid({"value": "x", "extra": 1}))

    query = load("examples/rpc-query.json")
    response = load("examples/rpc-response.json")
    for field in ("msg_id", "correlation_id", "ts"):
        negative("rpc", query, lambda x, field=field: x.pop(field), "RPC missing " + field + " rejected")
    negative("rpc", query, lambda x: x.update(type="UNKNOWN"), "unknown RPC type rejected")
    negative("rpc", query, lambda x: x.update(extra="x"), "extra RPC envelope field rejected")
    negative("rpc", query, lambda x: x["payload"].update(extra="x"), "extra typed payload field rejected")
    negative("rpc", query, lambda x: x.update(ts="not-a-dateZ"), "bad UTC date rejected")
    negative("rpc", query, lambda x: x.update(ts="2026-11-01T00:00:00+03:00"), "non-Z timestamp rejected")
    negative("rpc", query, lambda x: x.update(msg_id="not-a-uuid"), "invalid UUID rejected")
    negative("rpc", response, lambda x: x.pop("in_reply_to"), "response without parent rejected")
    check("query/response correlation", response["in_reply_to"] == query["msg_id"]
          and response["correlation_id"] == query["correlation_id"])
    check("UTF8 answer allowed", validator("rpc").is_valid(load("examples/rpc-human-answer.json")))
    types = load("contracts/rpc-types.json")
    branches = load("contracts/rpc.schema.json")["allOf"]
    branch_types = {x["if"]["properties"]["type"]["const"] for x in branches
                    if "const" in x["if"]["properties"]["type"]}
    check("RPC enum/payload registry complete", set(types) == branch_types
          == set(load("contracts/rpc.schema.json")["properties"]["type"]["enum"]))
    check("required new RPC types present", {"CONTRACT_CHANGED", "TALENT_MUTATION_REQUEST"} <= set(types))
    cases = load("examples/rpc-cases.json")
    check("all RPC types have complete fixtures", set(cases) == set(types))
    for kind, case in cases.items():
        check("complete typed RPC fixture: " + kind, validator("rpc").is_valid(case))
        negative("rpc", case, lambda x: x.update(payload={}), "empty typed payload rejected: " + kind)
    needs_info = copy.deepcopy(response)
    needs_info["payload"] = {"contract_ref": "checkout-v1", "status": "NEED_INFO", "question": "NEED FIELD"}
    check("NEED_INFO branch with question accepted", validator("rpc").is_valid(needs_info))
    negative("rpc", needs_info, lambda x: x["payload"].pop("question"), "NEED_INFO missing question rejected")

    charter = load("examples/charter.json")
    negative("charter", charter, lambda x: x.pop("created_at"), "Charter created_at required")
    negative("charter", charter, lambda x: x.update(lifecycle=[{"step_1": "SKELETON"}]),
             "Charter dict lifecycle rejected")
    check("developer response/disagreement permissions", {"CONTRACT_RESPONSE", "DISAGREEMENT_TICKET"}
          <= set(charter["allowed_rpc_types"]))
    node = load("examples/map-node.json")
    for field in ("created_at", "updated_at", "lease_epoch"):
        negative("map-node", node, lambda x, field=field: x.pop(field), "node " + field + " required")
    negative("map-node", node, lambda x: x.update(status="BLOCKED_HUMAN"), "blocked node needs resume metadata")
    negative("map-node", node, lambda x: x.update(assigned_to="agent-x"), "assigned node needs valid lease")
    verdict = load("examples/verdict.json")
    negative("verdict", verdict, lambda x: x.update(status="PASSED"), "PASSED with required UNRUN rejected")
    diary = load("examples/diary.json")
    check("synthetic diary not VERIFIED/injected", diary["status"] == "HYPOTHESIS"
          and diary["provenance"] == "SYNTHETIC" and diary["inject_as_rule"] is False)

    for name in ("node-fsm", "order-fsm"):
        fsm = load("contracts/" + name + ".json")
        states = set(fsm["statuses"])
        transitions = fsm["transitions"]
        check(name + " endpoints valid", all(t["from"] in states and t["to"] in states for t in transitions))
        check(name + " explicit guards", all(t["guard"] and t["event"] for t in transitions)
              and fsm["guards_are_mandatory"] is True)
        keys = [(t["from"], t["to"], t["event"]) for t in transitions]
        check(name + " no duplicate transition triples", len(keys) == len(set(keys)))
    fsm = load("contracts/node-fsm.json")
    edges = {(t["from"], t["to"]) for t in fsm["transitions"]}
    for edge in (("DONE", "READY"), ("BLOCKED_DEP", "READY"), ("IMPLEMENTING", "INTERRUPTED"),
                 ("INTERRUPTED", "BACKLOG"), ("INTERRUPTED", "SKELETON_PENDING")):
        check("node required edge " + "->".join(edge), edge in edges)
    check("no undefined TESTING state", "TESTING" not in fsm["statuses"])
    check("wait reason not a NodeStatus", "WAIT_PROVIDER" not in fsm["statuses"])
    check("schema/FSM node enum same", set(load("contracts/map-node.schema.json")["properties"]["status"]["enum"])
          == set(fsm["statuses"]))
    order = load("contracts/order-fsm.json")
    order_edges = {(t["from"], t["to"]) for t in order["transitions"]}
    for edge in (("ACCEPTED", "FILLED"), ("PARTIALLY_FILLED", "PARTIALLY_FILLED"),
                 ("PARTIALLY_FILLED", "CANCELLED"), ("PARTIALLY_FILLED", "EXPIRED")):
        check("order required edge " + "->".join(edge), edge in order_edges)

    check("Decimal scale equality counterexample", Decimal("1.0") == Decimal("1.00"))
    value, step = Decimal("1.03"), Decimal("0.05")
    check("quantize not arbitrary step", value.quantize(step, rounding=ROUND_DOWN) % step != 0)
    normalized = (value / step).to_integral_value(rounding=ROUND_DOWN) * step
    check("step floor example", normalized == Decimal("1.00") and normalized % step == 0)
    check("partial cancelled counterexample", Decimal("3") < Decimal("10"))
    check("unsigned fill sum not PnL", Decimal("100") + Decimal("110") != Decimal("110") - Decimal("100"))

    found = definitions(master)
    ids = [item["id"] for item in found]
    source_ids = load("contracts/source-requirement-ids.json")["requirement_ids"]
    check("all 650 original formal IDs retained exactly once", len(ids) == 650
          and len(ids) == len(set(ids)) and set(ids) == set(source_ids))
    index = load("contracts/requirements-index.json")["requirements"]
    check("requirement index fresh", [{"id": row["id"], "line": row["line"]} for row in index] == found)
    check("every requirement has a phase and honest evidence status", all(
        row["planned_phase"] and (ROOT / row["test_plan_ref"]).is_file()
        and row["owner"] == "ASSIGN_DURING_ORG_DESIGN"
        and row["implementation_status"] == "NOT_STARTED"
        and row["runtime_evidence_refs"] == [] for row in index))
    decisions = set(re.findall(r"^\| ([CD]-\d{2}) \|", master, re.M))
    check("decision registries complete", len(decisions) == 34)
    unresolved = set(re.findall(r"\b((?:[A-Z]+|DoD)-\d{2})\b", master)) - set(ids) - decisions
    check("formal references resolve", not unresolved, sorted(unresolved))
    rules = load("contracts/verifiers.json")["rules"]
    check("13 domain verifier rules", len(rules) == 13 and len({x["id"] for x in rules}) == 13)
    check("DoD verifier count agrees", "Все 13 правил §38.13" in master)
    check("secure sandbox is default", '| `sandbox.mode` | str | `"secure_docker"`' in master)
    check("loopback control bind is default", '| `web.host` | str | `"127.0.0.1"`' in master)
    check("ordinary subprocess is not default", '| `sandbox.mode` | str | `"subprocess"`' not in master)
    check("known contradictory invariant removed", "Ни одна строчка кода целевого проекта не попадает на диск" not in master)
    check("contract-ready scheduling policy present", "CONTRACT_FROZEN" in master and "IMPLEMENTATION_DONE" in master)

    class DialogueParser(HTMLParser):
        def __init__(self):
            super().__init__()
            self.roles = []
            self.active_markup = False

        def handle_starttag(self, tag, attrs):
            values = dict(attrs)
            if tag == "section":
                self.roles.append(values.get("data-role"))
            if tag in ("script", "iframe", "form", "object") or any(k.startswith("on") for k in values):
                self.active_markup = True

    dialogue = DialogueParser()
    dialogue.feed((ROOT / "razrabotka_orkestra.html").read_text())
    check("clean HTML contains exactly chronological 12 dialogue pairs",
          dialogue.roles == [role for _ in range(12) for role in ("user", "assistant")])
    check("clean dialogue has no executable/account UI markup", not dialogue.active_markup)

    with (ROOT / "docs/AUDIT_RESOLUTION.csv").open(newline="") as stream:
        audit = list(csv.DictReader(stream))
    check("all 37 audit findings traced", [r["audit_id"] for r in audit] == [f"{i:02}" for i in range(1, 38)])
    check("owner action remains explicit", audit[0]["specification_status"] == "SPEC_FIXED_OWNER_ACTION_REQUIRED")
    check("audit evidence files exist", all((ROOT / p).exists() for r in audit for p in r["evidence_paths"].split(";")))
    templates = list((ROOT / "prompts/templates").glob("*.md"))
    check("all 10 templates materialized", len(templates) == 10)
    for path in templates:
        content = path.read_text()
        check("role checklist/permissions: " + path.name,
              "External checklist:" in content and "broker permissions" in content
              and "UNRUN" in content and "hidden reasoning" in content)

    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or any(part in (".git", ".venv", "__pycache__") for part in path.parts):
            continue
        if path.suffix not in (".md", ".json", ".txt", ".html", ".csv", ".py", ".yaml"):
            continue
        content = path.read_text(encoding="utf-8")
        secret = re.search(r"(?:nvapi-|sk-)[A-Za-z0-9_-]{32,}|\b\d{8,12}:[A-Za-z0-9_-]{32,}", content)
        email = re.search(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", content)
        check("sanitized artifact: " + str(path.relative_to(ROOT)), not secret and not email)
        if path.suffix == ".md":
            for match in re.finditer(r"^```(python|json|yaml)\n(.*?)^```", content, re.M | re.S):
                language, body = match.groups()
                try:
                    {"python": ast.parse, "json": json.loads, "yaml": yaml.safe_load}[language](body)
                    check("fenced syntax: " + str(path.relative_to(ROOT)) + ":" + str(content[:match.start()].count("\n") + 1), True)
                except Exception as error:
                    check("fenced syntax: " + str(path.relative_to(ROOT)), False, type(error).__name__)
    for ref in sorted(set(re.findall(r"`((?:contracts|examples|prompts/templates)/[A-Za-z0-9_.-]+(?:\.json|\.yaml|\.md))`", master))):
        check("normative reference exists: " + ref, (ROOT / ref).is_file())


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        check("validation completed without internal errors", False, type(error).__name__ + ": " + str(error))
    passed = sum(item["passed"] for item in CHECKS)
    hashes = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(ROOT.rglob("*")) if p.is_file()
        and p != ROOT / "docs/VALIDATION.json"
        and not any(part in (".git", ".venv", "__pycache__") for part in p.parts)
    }
    result = {"scope": "DOCUMENTS_AND_FIXTURES_ONLY", "python": platform.python_version(),
              "dependencies": {name: importlib.metadata.version(name) for name in ("jsonschema", "PyYAML")},
              "checks_passed": passed, "checks_total": len(CHECKS), "checks": CHECKS,
              "source_master_sha256": hashlib.sha256((ROOT / "prompts/MASTER_PROMPT.md").read_bytes()).hexdigest(),
              "artifact_sha256": hashes,
              "unrun": ["runtime implementation", "Pydantic differential validation", "Windows/Docker containment",
                        "provider/exchange integration", "old key revocation/publication cleanup"]}
    (ROOT / "docs/VALIDATION.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(f"Document checks: {passed}/{len(CHECKS)} passed; runtime/live checks UNRUN")
    for item in CHECKS:
        if not item["passed"]:
            print("FAIL", item["check"], item["details"])
    sys.exit(0 if passed == len(CHECKS) else 1)
