# ORCHESTRA v1.3 — точные политики исполнения

Этот файл дополняет MASTER_PROMPT §39. Он описывает обязательное поведение
будущей реализации. Наличие текста, JSON Schema и passing document checks
не подтверждает исполнение этих политик продуктом.

## 1. Доверие, профиль и действия

Недоверенными являются сгенерированные код, тесты, install hooks, README,
модельные tool arguments и загруженные скиллы. Их текст не выдаёт полномочий.
Authentication/authorization живут в controller/broker policy, отдельно от LLM.

Secure profile до запуска подтверждает: отдельную identity; отсутствие host HOME,
секретов и Docker socket; readonly toolchain/acceptance tests; scoped mounts;
запрет внешней сети, включая direct IPv4/IPv6/DNS/host services; aggregate memory,
CPU, pids/output/disk/wallclock limits и остановку всего собственного дерева.
Negative probes — реальное поведение OS/container, не проверка proxy env.
Выход профиля из строя → BLOCKED_SANDBOX. trusted_subprocess требует явного
доверенного scope оператора и никогда не подменяет secure profile автоматически.
Loopback fixtures разрешены только внутри выделенного fixture profile.

Broker tools в contracts/tool-policy.json — доверенный код с typed commands:
patch proposal, verify, git integration, research, signer. Они не импортируют
код агента и не дают произвольный shell/secret_ref/path/flags. Signer получает
минимальный account/exchange/operation scope и не передаёт секрет модели.

Web control требует authentication даже на loopback, Origin checking для WS,
project authorization и request/connection/output limits. Без credentials
работает лишь локальный health без данных/управления. Remote bind требует TLS.
Session credentials не помещаются в URL. Path scope проверяет junction/symlink/
reparse/ADS/UNC/drive paths и защищает open/apply от TOCTOU.

## 2. Проверка кандидата и интеграция

Рабочие состояния: draft → staging → verified candidate → accepted manifest.
До green разрешено писать только staging. Каждый кандидат имеет source digest,
dependency lock, protected test digest, toolchain/environment digest и lease epoch.
Инструменты/конфиги судьи и независимые acceptance tests не writable агентом;
запуск из его venv не является доверенной проверкой.

Скелет: parse/lint/types. TDD_RED: зафиксированные failing tests по корректной
причине. Законченный атом: syntax/types/affected tests и принятая регрессия;
не реализованная часть имеет заранее перечисленный expected-red scope.
Финальный узел: все обязательные acceptance checks и независимый QA зелёные.
Не прятать неожиданные failures под expected red или skipped.

MAX_RETRIES=2 — предел rejected candidate attempts узла (включая первый).
JG max_verify_iterations=2 также включает первую проверку кандидата; это не
дополнительные два круга поверх уже исчерпанных попыток. Каждый rejected candidate
инкрементирует единый node counter один раз; после второго rejection → ESCALATED.
Атомы, не имеющие дефекта, не расходуют этот счётчик. Сетевые attempts имеют
свой bounded counter, но все расходы входят в общий node/project budget.

Интегратор единственный изменяет принятую ветку. Под общей lock проверяет:
актуальность policy/contract/lease epoch; file ownership; точные file preimages;
source/test/environment digests; mandatory evidence. Использует отдельный index
и staging каждого кандидата. Concurrent changes требуют нового candidate/retest,
не безусловного rebase уже выданного verdict.

Все файлы кандидата immutable до выбора нового accepted manifest/commit. Только
переключение manifest является публикацией. Отдельные rename файлов не выдаются
за многофайловую atomic transaction. При REJECTED принятый manifest не меняется.

## 3. Состояние, журнал, outbox и crash

StateStore принимает типизированные команды: command_id, authenticated actor,
expected_version, lease_id/epoch и payload. Права и FSM guards проверяются до
мутации. Single-writer обеспечивает последовательный durable commit:

1. Проверить команду на копии состояния, назначить seq/event_id/map_version.
2. Записать framed event с длиной/checksum и fsync. Только после этого применять
   state и давать ack. Replay применяет event_id один раз.
3. Snapshot содержит snapshot_seq/map_version и checksum без собственного поля
   checksum; write/flush/fsync/replace, directory fsync где поддержан.
4. Outbox command входит в тот же durable event. Внешняя доставка повторяема;
   consumer фиксирует dedup/effect/ack согласованным durable протоколом.
5. Интеграция файлов имеет PREPARE(candidate digest, preimages, epoch), immutable
   commit/manifest creation и durable COMMIT публикации. Recovery проверяет оба
   мира: PREPARE без COMMIT не считается accepted; orphan commit сохраняется как
   candidate, не молча публикуется. COMMIT с отсутствующими байтами — fail closed.
   На диске принятый ref переключается только после COMMIT; crash после COMMIT
   восстанавливает этот ref из immutable commit. Ref не является authority сам по себе.

Полный валидный framed tail без ack допустимо replay-ить; неполный последний frame
сохраняется как evidence и отсекается до последней valid durable boundary.
Checksum failure/seq gap в принятой середине журнала — отказ старта, не тихая
потеря событий. Retention не удаляет незакрытые outbox/effects и checkpoint parents.
Schema migrations событий/снапшота версионируются и тестируются на старых fixtures.

Chaos acceptance убивает процесс между каждым шагом, включая fsync/commit/ack.
Закрытые результаты не теряются, эффекты не дублируются; незавершённое вычисление
может повториться. Не обещать exactly-once HTTP на внешней стороне без её договора.
Snapshot backup/restore также проверяет целостность referenced immutable artifacts.

## 4. Аренды, ожидания, FSM и проектирование

Монотонный fencing epoch меняется при новой выдаче узла. Patch/verdict/git/publish
проверяют epoch в broker. Deadline lease определяется Clock и persisted expiry;
после restart требуется revalidation. Нельзя публиковать late result прежней аренды.
Перед reuse stopping подтверждает отсутствие старых процессов либо все их эффекты
надёжно отклоняются fencing. Нет старого процесса/эффекта → новый dispatch разрешён.

FSM — contracts/node-fsm.json; guards обязательны. BLOCKED_HUMAN сохраняет
resume_status/reason/question_id и освобождает scarce agent/key slots; resume
получает свежую lease и валидирует checkpoint. WAIT_PROVIDER — wait reason, не
новый NodeStatus. BLOCKED_DEP→READY и DONE→READY CONTRACT_REOPEN явны; reopen
инвалидирует зависимые verdicts/contract digests, а не переписывает прошлое evidence.

Draft DAG предшествует Org Design. Сначала provisional Charter, после S4 финальная
проверка topology. Dependencies типизированы: CONTRACT_FROZEN разрешает staging
реализацию потребителя, IMPLEMENTATION_DONE нужна для интеграции/реальных вызовов.
TaskGroup supervisor превращает ожидаемые node failures в results, сохраняя
independent branches; неожиданная ошибка ядра инициирует общую безопасную остановку.

## 5. LLM, quota scopes, кэш и capability

Provider interface stream_chat(req, CredentialHandle) возвращает AsyncIterator
непосредственно (def в Protocol, async generator в реализации). Probe асинхронен.
ClientFactory и KeyPool broker связывают opaque handle с credentials; модель не
получает секреты. UUID4 обеспечивает уникальность, seq — порядок.

Probe ограничен общей deadline/attempt/token policy, каждый параметр проверяется
отдельно. supported/unsupported/unknown различаются; успешный запрос не означает,
что параметр соблюдён. Model/context/pricing baseline имеет источник/дату/версию.
Cache key включает endpoint/API/model/credential-scope/probe-policy digest.

Key availability и active leases раздельны. При release INVALID/EXHAUSTED/COOLDOWN
не отменяются параллельным SUCCESS. Lease ID/epoch обеспечивают idempotent release.
Credential/account/project/model/IP quota scopes следуют adapter contract. Ротация
не обходит общий limit; неизвестная квота обрабатывается консервативно.

Logical request содержит все network attempts/probe/repair/continuation. Общий
deadline+token+cost budget проверяется до каждого attempt. Retry-After соблюдается
по scope. Оборванный стрим не исполняет частичные tool arguments. Replayed tool
effects защищены persistent command_id. Unknown usage отмечается unknown/estimated,
не превращается в бесплатный ноль. Кэш не replay-ит эффекты и учитывает data scope.

Контекст: input+history+tool schemas/results+reserved output+reasoning accounting
адаптера+margin. Protected instructions/contracts нельзя усекать ради долей
20/30/50; эти доли мягкие, непоместившийся mandatory scope → split/BLOCKED_SPEC.
Reasoning stream необязателен и не доказывает действия. Проверяется внешний
краткий checklist/summary и реальные receipts, не скрытые мысли.

## 6. Wire language, approvals и шаблоны

Все типы/metadata/payload contracts в contracts/rpc.schema.json. Только wire keys,
enums и IDs ограничены ASCII. Пользовательский текст, код и evidence — UTF-8.
Применять style validator к control prose, не ломая identifiers и цитаты.
Message TTL не является разрешением операции. Expired new command получает durable
EXPIRED ack без эффекта. Consumer dedup и origin identity подтверждает controller,
а не поля sender/decision_id, предложенные моделью.

BUSINESS/SECURITY/LIVE/RESOURCE требуют owner decision. Technical default допустим
лишь в заранее авторизованном scope; иначе timeout=pause_node. Approval привязан
к project/account/market/config digest/deadline; changed scope/restart/runtime
session делает LIVE approval недействительным до повторного принятия. Late answer
не возобновляет истёкшее разрешение. Duplicate answer — no-op.

Templates в prompts/templates/ — исходники для будущего prompt builder; не код
рантайма. Каждая роль получает external checklist и typed outputs, не запрос hidden
reasoning. Pure skills и privileged broker tools различаются явно. QA не автор
кода, acceptance tests независимы и защищены от ослабления.

## 7. Skills, профили и опыт

Project lock pin-ит skill/profile/contract version+digest. Изменение immutable
candidate проходит baseline+new tests+protected consumer regression+schema и
semantic compatibility. Manifest публикуется CAS под lock. Одновременная вторая
мутация не перезаписывает первую; работающий consumer сохраняет старый digest.
Quarantine scope — конкретный defective digest, не любой внешний сбой.

VERIFIED diary rule требует реального fail/repro/fix/validation и immutable receipts,
scope/technology versions/conditions. Количество новых записей 0..N; рост числа
правил не критерий успеха. Дедупликация сохраняет порядок, отрицания и условия.
Synthetic примеры не seed-ят реальный опыт; `.dict()` deprecated в Pydantic v2,
а не удалён. Транзакционные рекомендации зависят от workflow/outbox/recovery,
универсальное «commit перед каждым внешним вызовом» запрещено.

## 8. Торговые обязательства

Offline demo явно SYNTHETIC/PAPER/disabled external exchanges. Он не требует
выбора боевого капитала и не подтверждает совместимость live API. Actual deployment
требует DP-70 intake и минимум двух protocol-specific adapter fixtures; actual
recordings имеют source/version/date/license/digest и redaction.

Order FSM — contracts/order-fsm.json. Durable intent/clientOrderId/risk reservation
предшествуют send. UNKNOWN сохраняет резерв; openOrders или временный not-found
не доказывают отсутствие эффекта. Reconcile проверяет history/fills/visibility
horizon до ABSENT_CONFIRMED. Только затем возможен новый intent с новым ID.
Late fill/cancel races и direct ACCEPTED→FILLED обязательны в behavior tests.

Сумма unique fills = filled_qty <= original_qty, FILLED требует равенства,
CANCELLED/EXPIRED допускают частичное исполнение. Spot balance, borrow/margin,
linear/inverse/option contracts различаются capability. Ledger scope включает
exchange/account/subaccount/market, валюту и contract multiplier. PnL разделяет
realized/unrealized, fees/funding и FX valuation/as_of; unsigned Σ(qty*price)
не является PnL. Подробную market policy утверждать до разрешения соответствующего
рынка; неподдержанная модель закрыта по умолчанию.

Decimal equality не зависит от scale. quantize меняет exponent, не произвольную
кратность: 1.03 quantize 0.05 = 1.03. Для положительных величин normalization
floor(value/step)*step требует последующей проверки min/max/notional/side policy.
NaN/Infinity/negative/zero и precision bounds отклоняются по контракту; rounding
не должен скрывать reconciliation mismatch.

Risk check+reservation атомарны в общем exposure scope. Kill switch сначала
durable HALT/admission closed, затем bounded cancel/reconcile/close. Неудачная
отмена не открывает gate, crash сохраняет HALT, reset имеет authenticated gate.
LIVE gate стоит в execution path, не просто обнаруживается AST поиском флага.

Replay ordering учитывает available_at, exchange/stream/sequence и event time;
causal as-of join не видит будущего/неполученного события. Late data, clock
uncertainty, revisable bars и watermark policy заданы. Digest сравнивает canonical
semantic result с pinned inputs; wall-clock/UUID/telemetry исключаются явно.

Signing/auth/book-resync/nonce/keepalive задаёт конкретная версия адаптера:
HMAC/Ed25519/RSA и listenKey/lastUpdateId не универсальные требования. Передача
нового адаптера может добавлять свои fixtures/capabilities без изменения core;
новая общая семантика требует versioned ADR и ретест, а не обход проверок.

## 9. Платформы и доказательства

Windows Job Object containment, aggregate limits, CPU control и mount mapping
проверяются на реальном Windows profile. CLI context Windows/WSL/daemon и mount
source/target различаются; path string conversion не доказывает mount identity.
Не требуется global Git config/Defender exclusion. Portable Python entrypoint
дополняется optional Makefile. Linux Docker build — отдельный Ubuntu job.

Evidence categories: DOCUMENT_VALIDATED, UNIT/MOCK_VERIFIED, SANDBOX_VERIFIED,
WINDOWS_VERIFIED, PROVIDER_VERIFIED, EXCHANGE_VERIFIED, INTEGRATION_VERIFIED.
Одно не заменяет другое. Отсутствующие credentials/стенды имеют UNRUN/BLOCKED,
не PASSED. Все metrics имеют host/profile/dataset/model/version, p50/p95 и scope.
Token economy измеряется реальным tokenizer полных сообщений; нет коэффициента
«русский в три раза» или универсального оптимального числа агентов.
