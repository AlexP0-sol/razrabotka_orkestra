# Фазы реализации и обязательные входы

Всегда доступны MASTER_PROMPT, EXECUTION_CONTRACT, contracts, templates, source
analysis, security status и актуальный PROGRESS. Неполное дробление README v1.2
отменено. Mocks не означают финальную работоспособность будущего контура.

| Фаза | Входы сверх mandatory bundle | Проверяемая поставка |
|---|---|---|
| P0 | Все architecture/quality/DoD требования | ADR, contracts, lock baseline, canonical paths, platform/test plan; document checks |
| P1 | P0 + PRV/CFG + credential boundary | Config/provider contract, fake HTTP; lint/types/isolated tests |
| P2 | P1 + quota/usage/cache policy | KeyPool/LLM; concurrent outcomes, unknown usage, bounded attempts |
| P3 | P0 + FSM/WAL/fencing/outbox | StateStore; durable-boundary fault injection и guards |
| P4 | P1/P2/P3 interfaces + draft DAG | Charters/runtime/scheduler; отсутствующие verifier/tools/research оставляют только LOCAL_VERIFIED |
| P5 | P3 + RPC/approval policy | Durable transport, expiry/dedup/identity tests |
| P6 | P3/P5 + protected tool interfaces | Skills/profiles/diaries; immutable versions, CAS, capability denials |
| P7 | P0 safe profile + P3/fencing | Real sandbox, protected judge/git; negative containment/ownership tests |
| P8 | P1/P7 research boundary | Grounding, source/version records, allowlist и isolated imports |
| P9 | P3/P4/P5 + authenticated control | Telegram/Web/CLI; auth/Origin/path/project checks, durable questions |
| P10 | Runtime interfaces + platform policy | Real redaction/retention/shutdown; Windows+Ubuntu jobs |
| P11 | P4/P6 + полные templates | Prompt builder; complete budgets/protected context и role/action policy |
| P11b | P6/P7/P8/P11 + trading contracts | DomainPack, SYNTHETIC offline fixtures; без live approval |
| P12 | Реальные зависимости прежних фаз | Protected acceptance/integration/chaos/platform jobs; честные UNRUN |
| P13 | P12 receipts + DoD | Runbook, reproducible artifact, evidence matrix; remaining gates |

Модульные тесты поставляются вместе с фазой. Недоступный стенд/credentials не
заменяется passing mock. Гейты привязаны к source/test/environment digests.
Канонические пути модулей задаёт §10 MASTER; краткие имена P-фаз не создают дубли.
P0 уточняет дерево только явным ADR и requirement→path→test проверкой.
Runtime Pydantic models требуют differential tests с JSON Schema/fixtures.

Live provider/exchange jobs требуют credentials и авторизованный scope. Здесь
ни один live job не запускался. Windows job не заменяется проверкой строк путей
под Linux. При возобновлении проверить последнюю принятую фазу и продолжить
первую незавершённую; уже принятые эффекты повторно не исполняются.
