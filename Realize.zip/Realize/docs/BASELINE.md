# Что подтверждено

Проверочные зависимости requirements-checks.txt зафиксированы по фактически
доступной среде. Это не заявление об их новизне и не baseline runtime фабрики.
Валидатор сам регистрирует строгие UUID4/UTC date-time formats без необязательных
сетевых зависимостей. Runtime Pydantic не установлен и не проверялся.

Названия моделей/сниппеты из исходного диалога — исторический контекст. Доступность,
capabilities, context/output accounting, pricing и quota scopes требуют provider
baseline с источником/датой/версией и отдельной live проверкой. Это ещё не выполнено.

Перед реализацией P0 проверяет совместимые стабильные версии по первичным индексам,
фиксирует exact locks/hashes и platform compatibility. Не ставить «latest» и не
считать минимальные кандидаты §34 уже проверенным reproducible lock. Изменения
baseline сопровождаются ADR и обновлением source/test/environment receipts.
